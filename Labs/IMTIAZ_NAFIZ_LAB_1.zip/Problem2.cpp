#include <iostream>

using namespace std;

int main(){
    double x , y, sum, average ; 
    cout << "Please enter the first number: ";
    cin >> x ; 
    cout << "Please enter the second number:";
    cin >> y;
    sum = x + y; 
    average = sum / 2 ; 
    cout << "Average of two numbers is " << average << ".\n" ; 
return 0;
}

